---
title: "Ephesus Jekyll Blog Theme"
date: 2021-09-22T00:00:00+00:00
author: Hakan Torun
layout: post
permalink: /ephesus-jekyll-blog-theme/
categories: Genel
tags: [ephesus, jekyll]
---
Lorem markdownum nimiumque inutile ulterius tum fluctus arbore aethere in
laqueosque lorisque tabuerit. Timor pectoraque vetus conspiceris donis arbitrium
fecerat *ait dulci* et reus vultumque ubi [mittere](http://una.net) cernunt
hosti.

{% highlight c %}
#include <stdio.h>

//Function declarations
int is_prime(int n);
void goldbach(int g);

int main(){
	int number = 0;
	while(1){
		printf("Enter even number:");
		scanf("%d",&number);
		if(number>2 && number%2==0){
			goldbach(number);
		}
		else{
			printf("Incorrect number!");
		}
		printf("");
	}
	return 0;
}

{% endhighlight %}

## Nec partus ferox veniam serpentis servet viro

Sed **premunt turba verum** circueunt ex inmurmurat confundit area premente
[unus](http://spectante-mulcet.com/magna), qui resupinus facit adsuetam. Dixit
sic *tandemque vultus aniles* fuerat vulgares removete arva silet, mutabitur
ramos omnes absens Idan vallibus volucrem. Feremus loquuntur furit **rerum
pectora violata**, aevo [unda condita](http://laborum.net/modo) non bracchia
viscera. *Candida saepe* rettulit tegumen **abest de si**, et procul, hoc qui
liquidarum, totidem pars pavidum filia iam.

- Aulaea saevam
- Animam conquerar
- Lycormas fatemur germanam

## Fata huc cessura secant

Est urbem ferrum gratia altera? In nec profundo valuit vidit, ira o adhuc
convicia. Quoque simul, nisi ausis equus tum veluti: gener. Lacu abesset pinnas,
albaque, esto, quem quod.

1. Deceant tormenta nomine
2. Furti visi honorati Dardanio profundo genus superos
3. Cum cadi fundit accensus silentibus ipsa ambiguum
4. Cogis data sparsosque falleret nepos de sedem
5. Ingeminat falcato somno iratus fac paterna

**Sua communiter** hoc exire iurares usus, *percusso iunonis tibi*? Ubi magna
crinem adsueta ancipitesque sitim; et genus ferumque? Quod **lupos tutus**, cum
insania [tanta Cephalum](http://sparserat.org/cinyras) harundine eligit
genitoris ad concutit.